=======
pygcode
=======

GCODE Parser for Python

Currently in development, ``pygcode`` is a low-level GCode interpreter
for python.


Installation
============

Install using ``pip``

``pip install pygcode``

or `download directly from PyPi <https://pypi.python.org/pypi/pygcode>`__


Documentation
=============

`Check out the wiki <https://github.com/fragmuffin/pygcode/wiki>`__ for documentation.


